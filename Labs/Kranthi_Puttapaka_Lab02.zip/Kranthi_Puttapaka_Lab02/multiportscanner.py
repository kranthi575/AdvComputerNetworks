#!/usr/bin/python3
import socket
import sys

# create a TCP socket
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# get user input for IP address and port range
ip, port1, port2 = input("Enter IP address and port range (start_port end_port): ").split()

# make a connection to the server
for port in range(int(port1), int(port2)):
    if sock.connect_ex((ip, port)) == 0:
        print('Port', port, 'is open')
    else:
        print('Port', port, 'is closed')

# close the socket when done
sock.close()


