# view mycode.py
#!/usr/bin/env python3
from scapy.all import *
a = IP()
a.show()
