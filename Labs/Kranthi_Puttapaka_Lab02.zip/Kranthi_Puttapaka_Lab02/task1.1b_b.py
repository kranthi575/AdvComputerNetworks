#!/usr/bin/env python3
from scapy.all import *

def print_pkt(pkt):
  pkt.show()

# Capture any TCP packet that comes from a particular IP and with a destination port number 23.
pkt = sniff(iface='br-40327300a6bb', filter='tcp && src host 10.9.0.6 && dst port 23', prn=print_pkt)
